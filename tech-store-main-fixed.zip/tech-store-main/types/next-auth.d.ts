import type { DefaultSession } from "next-auth";

// بدون الملف ده، TypeScript مش هيعرف إن session.user فيها id وrole —
// دول حقول إحنا ضفناها بنفسنا في auth.ts (jwt/session callbacks)،
// مش موجودة افتراضيًا في نوع Session بتاع NextAuth.
declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      role: "CUSTOMER" | "ADMIN";
    } & DefaultSession["user"];
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    id: string;
    role: "CUSTOMER" | "ADMIN";
  }
}
